import pandas as pd
from sklearn.cluster import KMeans

class DataAgent:

    def analyze(self, data_path: str):

        df = pd.read_csv(data_path)

        features = df[["reject_rate", "distance", "income"]]

        model = KMeans(n_clusters=3, random_state=42)
        labels = model.fit_predict(features)

        df["cluster"] = labels

        return df.groupby("cluster").mean().to_dict()