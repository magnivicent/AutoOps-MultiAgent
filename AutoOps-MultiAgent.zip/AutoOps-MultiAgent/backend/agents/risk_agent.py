class RiskAgent:

    def check(self, strategy):

        risks = []

        if strategy.get("dynamic_bonus"):
            risks.append("需要控制补贴预算")

        return {
            "safe": True,
            "risks": risks
        }