class ReportAgent:

    def build_report(self, analysis, strategy, risk):

        report = f'''
# 自动运营分析报告

## 数据分析
{analysis}

## 策略建议
{strategy}

## 风险分析
{risk}
'''

        return report