class PlannerAgent:

    def plan(self, query: str):

        tasks = [
            "collect_data",
            "analyze_data",
            "generate_strategy",
            "risk_check",
            "generate_report"
        ]

        return tasks