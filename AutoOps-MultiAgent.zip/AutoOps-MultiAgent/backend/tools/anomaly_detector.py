from sklearn.ensemble import IsolationForest
import pandas as pd

class AnomalyDetector:

    def detect(self, path):

        df = pd.read_csv(path)

        model = IsolationForest(contamination=0.05, random_state=42)

        df["anomaly"] = model.fit_predict(
            df[["reject_rate"]]
        )

        return df[df["anomaly"] == -1]