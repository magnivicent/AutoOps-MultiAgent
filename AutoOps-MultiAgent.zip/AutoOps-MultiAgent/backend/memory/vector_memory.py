import chromadb

class VectorMemory:

    def __init__(self):
        self.client = chromadb.Client()
        self.collection = self.client.create_collection("memory")

    def add_memory(self, text):
        self.collection.add(
            documents=[text],
            ids=[str(hash(text))]
        )

    def search(self, query):
        return self.collection.query(
            query_texts=[query],
            n_results=3
        )