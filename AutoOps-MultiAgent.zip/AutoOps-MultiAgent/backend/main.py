from fastapi import FastAPI
from api.routes import router

app = FastAPI(title="AutoOps Multi-Agent System")

app.include_router(router)

@app.get("/")
def home():
    return {"message": "AutoOps Multi-Agent System Running"}