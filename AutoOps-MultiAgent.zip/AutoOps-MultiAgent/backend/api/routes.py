from fastapi import APIRouter
from workflows.main_workflow import run_workflow

router = APIRouter()

@router.post("/run")
async def run_task(task: dict):
    result = await run_workflow(task["query"])
    return {"result": result}