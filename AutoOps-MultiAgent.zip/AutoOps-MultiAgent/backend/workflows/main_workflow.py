from agents.planner_agent import PlannerAgent
from agents.data_agent import DataAgent
from agents.strategy_agent import StrategyAgent
from agents.risk_agent import RiskAgent
from agents.report_agent import ReportAgent

planner = PlannerAgent()
data_agent = DataAgent()
strategy_agent = StrategyAgent()
risk_agent = RiskAgent()
report_agent = ReportAgent()

async def run_workflow(query: str):

    tasks = planner.plan(query)

    analysis = data_agent.analyze("data/rider_data.csv")

    strategy = strategy_agent.generate(analysis)

    risk = risk_agent.check(strategy)

    report = report_agent.build_report(
        analysis,
        strategy,
        risk
    )

    return {
        "query": query,
        "tasks": tasks,
        "report": report
    }